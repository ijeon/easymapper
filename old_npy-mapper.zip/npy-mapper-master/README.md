# npy-mapper
jQuery GUI Image Map Markup Generator
